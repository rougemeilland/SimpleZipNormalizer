#region アセンブリ Xceed.Zip, Version=7.1.23524.12120, Culture=neutral, PublicKeyToken=ba83ff368b7563c6
// 不明な場所
// Decompiled with ICSharpCode.Decompiler 8.1.1.7464
#endregion

using System;
using System.IO;
using System.Text;
using Xceed.Utils.Exceptions;
using Xceed.Utils.Paths;

namespace Xceed.Zip;

internal class UnicodeExtraHeader : ExtraHeader
{
    public const short UnicodeSignature = 21838;

    private const int InnerUnicodeSignature = 1480807758;

    public UnicodeExtraHeader()
        : base(21838)
    {
    }

    public override ExtraHeader CreateInstance(ItemHeader header)
    {
        return this;
    }

    public override bool Read(ItemHeader header, ItemHeader.TransientData transientData, byte[] data, int offset, int size, bool fromCentralHeader)
    {
        if (header == null)
        {
            throw new ArgumentNullException("header");
        }

        if (data == null)
        {
            throw new ArgumentNullException("data");
        }

        if (offset < 0 || offset > data.Length)
        {
            Xceed.Utils.Exceptions.ThrowException.ThrowArgumentOutOfRangeException("offset", offset, "The offset is out of range.");
        }

        checked
        {
            if (size < 0 || offset + size > data.Length)
            {
                Xceed.Utils.Exceptions.ThrowException.ThrowArgumentOutOfRangeException("size", size, "The size is out of range.");
            }

            int num = (fromCentralHeader ? 8 : 6);
            if (size < num)
            {
                throw new InvalidZipStructureException("The Unicode extra header's reported size is too small.");
            }

            int num2 = BitConverter.ToInt32(data, offset);
            offset += 4;
            if (num2 != 1480807758)
            {
                return false;
            }

            short num3 = BitConverter.ToInt16(data, offset);
            offset += 2;
            short num4 = 0;
            if (fromCentralHeader)
            {
                num4 = BitConverter.ToInt16(data, offset);
                offset += 2;
            }

            if (num3 * 2 + num4 * 2 > size - num)
            {
                throw new InvalidZipStructureException("The Unicode extra header's reported filename and comment sizes exceed the extra header size.");
            }

            if (num3 > 0)
            {
                string filename = Encoding.Unicode.GetString(data, offset, num3 * 2).Replace('/', Xceed.Utils.Paths.Path.DirectorySeparatorChar);
                offset += num3 * 2;
                if (fromCentralHeader || header.Streaming)
                {
                    filename = ItemHeader.FixFilename(filename);
                    header.FileName = filename;
                }
            }

            if (num4 > 0)
            {
                header.FileComment = Encoding.Unicode.GetString(data, offset, num4 * 2);
                offset += num4 * 2;
            }

            return true;
        }
    }

    public override short Write(ItemHeader header, ItemHeader.TransientData transientData, BinaryWriter writer, bool forCentralHeader)
    {
        if (header == null)
        {
            throw new ArgumentNullException("header");
        }

        if (writer == null)
        {
            throw new ArgumentNullException("writer");
        }

        writer.Write(base.Signature);
        ushort num = 6;
        string filename = transientData.Filename;
        byte[] bytes = Encoding.Unicode.GetBytes(filename);
        checked
        {
            num = (ushort)(num + unchecked((ushort)bytes.Length));
            byte[] array = null;
            if (forCentralHeader)
            {
                array = Encoding.Unicode.GetBytes(header.FileComment);
                num = (ushort)(num + unchecked((ushort)(array.Length + 2)));
            }

            writer.Write(num);
            writer.Write(1480807758);
            writer.Write((ushort)(bytes.Length >> 1));
            if (forCentralHeader)
            {
                writer.Write((ushort)(array.Length >> 1));
            }

            if (bytes.Length != 0)
            {
                writer.Write(bytes);
            }

            if (forCentralHeader && array.Length != 0)
            {
                writer.Write(array);
            }
        }

        return (short)num;
    }
}
#if false // 逆コンパイルのログ
キャッシュ内の '8' 個の項目
------------------
解決: "mscorlib, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b77a5c561934e089"
1 つのアセンブリが見つかりました: 'mscorlib, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b77a5c561934e089'
読み込み元: 'C:\Program Files (x86)\Reference Assemblies\Microsoft\Framework\.NETFramework\v4.0\mscorlib.dll'
------------------
解決: "System, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b77a5c561934e089"
1 つのアセンブリが見つかりました: 'System, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b77a5c561934e089'
読み込み元: 'C:\Program Files (x86)\Reference Assemblies\Microsoft\Framework\.NETFramework\v4.0\System.dll'
------------------
解決: "Xceed.FileSystem, Version=7.1.23524.12120, Culture=neutral, PublicKeyToken=ba83ff368b7563c6"
1 つのアセンブリが見つかりました: 'Xceed.FileSystem, Version=7.1.23524.12120, Culture=neutral, PublicKeyToken=ba83ff368b7563c6'
読み込み元: 'C:\Program Files (x86)\Xceed\Xceed Zip for .NET v7.1\Bin\Xceed.FileSystem.dll'
------------------
解決: "Xceed.Compression, Version=7.1.23524.12120, Culture=neutral, PublicKeyToken=ba83ff368b7563c6"
1 つのアセンブリが見つかりました: 'Xceed.Compression, Version=7.1.23524.12120, Culture=neutral, PublicKeyToken=ba83ff368b7563c6'
読み込み元: 'C:\Program Files (x86)\Xceed\Xceed Zip for .NET v7.1\Bin\Xceed.Compression.dll'
------------------
解決: "System.Drawing, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a"
名前 'System.Drawing, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a' で見つけることができませんでした
#endif
